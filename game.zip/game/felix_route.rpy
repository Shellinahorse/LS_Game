#File created by me (Usman)

# Felix's route
label felix_route_start:
    #show felix at felix_center
    show felix_sketch_scaled at felix_center
    f "You chose me. Let's see where this takes us."
    jump felix_classroom_scene

label felix_classroom_scene:
        stop music fadeout 2.0
        scene classroom

        teacher "Today will be a working session. You will be paired with a partner and you'll present your findings at the end of the week."
    
        f_thoughts "Another group project... Just great."
    
        teacher "Felix and Bridgette, you’ll be working together for this assignment."

        f_thoughts "Bridgette. Hm. This could be... interesting."

        # Bridgette "runs in" from left side
        show bridgette_sketch_scaled at offscreenleft
        with dissolve

        pause 0.2
        play sound "audio/running_downstairs.mp3" volume 0.3
        pause 1.0
        show bridgette_sketch_scaled:
            moveacross
        with dissolve

        #$ run_in("bridgette_sketch_scaled")
        b "Ah—Sorry I'm late!"
        stop sound

        f_thoughts "Late. Flustered. Chaotic energy confirmed."

        #show bridgette_sketch_scaled at bridgette_center

        # FIRST CHOICE - How does Felix react?
        menu:
            "How does Felix react to being paired with Bridgette?"
            "Indifferent":
                f "Understood."
                f_thoughts "As long as she does her part, this should be fine."
                $ felix_bridgette_bond += 1
            "Annoyed":
                f "...Great." # Felix sighs
                f_thoughts "Out of everyone, it had to be her?"
            "Secretly Interested":
                f "Well then, let's get to work." # A rare smirk from Felix
                f_thoughts "This might not be so bad after all."
                $ felix_bridgette_bond += 2
        jump project_scene_felix

label project_scene_felix:
        teacher "Alright, get to work!"

        b "I-I’ll take care of the research, if that’s alright with you..."
        
        f "Sounds good."
        
        f_thoughts "At least she’s taking the initiative."

        play music "audio/tower_clock_chime.mp3" volume 0.3 
        teacher "That's it for today. Remember to keep working on your projects!"
        stop music fadeout 2.0

        show bridgette_sketch_scaled at bridgette_center, idle_bounce

        b "I'll see you later! ...And he's already gone."

        # SECOND CHOICE - Does Felix stay or leave?
        menu:
            "What does Felix do?"
            "Keep Walking":
                f_thoughts "No point in sticking around."
                jump hallway_scene_felix
            "Wait for Bridgette":
                f "..."
                f_thoughts "Maybe I should—... No, never mind."
                jump hallway_scene_felix

label hallway_scene_felix:
        scene auditorium_outside_evening

        f_thoughts "Finally, I can head home and check the new posts on Velvet Veil."

        show bridgette_sketch_scaled at bridgette_center, idle_bounce
        b "Hey Felix!"

        f_thoughts "Huh? Bridgette?"  
        f "..."  

        f_thoughts "She actually followed me. What does she want now?"  

        b "I was wondering if you wanted to stick--study together? I mean, you can totally decline if you want to, but I thought, I figured I'd ask because we are partners, but you're really smart and probably don't need my help, but two brains are better than one, and—"

        f "..."  

        f_thoughts "She’s rambling again. Why does she always do that?"  

        f "...Thanks, but I already have plans today."  

        b "O-oh..."  

        f_thoughts "I probably could’ve been less blunt… but it’s true."  

        #Background characters discussing Velvet Veil  
        "Kevin" "Did you see the new thread on Velvet Veil last night? Someone called 'Phantom' posted a riddle, and no one can solve it!"  

        f_thoughts "Phantom finally posted something new? Interesting."  

        "Victor" "I know! And that user, Chat Blanc, had the wittiest reply. He's so mysterious."  

        f_thoughts "Tch. Mysterious, huh?"  

        jump night_forum_felix 

label night_forum_felix:
        scene room_evening_light_on with fade
        
        f_thoughts "Another day, another performance."
        f_thoughts "At least now, I can finally be myself."

        #scene bg_laptop with fade
        
        f_thoughts "Velvet Veil... No faces, no names. Just words."
        f_thoughts "A perfect mask."

        scene bg_forum with fade#Logging in
        
        f_thoughts "Let’s see if tonight brings anything interesting."

        #Bridgette logs on as Princess Justice
        $ preferences.text_cps = 20

        show screen mask_icon("pj")
        pj "Hi. Is anyone here?"

        $ preferences.text_cps = 0

        f_thoughts "A new username..."
        f_thoughts "Princess Justice? How... idealistic."

        $ preferences.text_cps = 20

        #show screen typing_indicator("Chat Blanc")
        show screen mask_icon("cb")
        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(1.0)
        stop sound
        hide screen blinking_cursor
        #hide screen typing_indicator

        cb "Welcome to the Velvet Veil, Princess Justice."

        #Pause before response
        show screen mask_icon("pj")
        pj "Oh, um… hi?"

        $ preferences.text_cps = 0

        f_thoughts "Hesitant. New. Curious."

        $ preferences.text_cps = 20

        show screen mask_icon("cb")
        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(1.0)
        stop sound
        hide screen blinking_cursor

        cb "A new username… You're new here, aren't you?"

        show screen mask_icon("pj")
        pj "Yeah. I guess I'm just… curious about this place."

        show screen mask_icon("cb")
        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(1.0)
        stop sound
        hide screen blinking_cursor
        cb "Curiosity is a good thing. Some say it’s dangerous, but I find it refreshing."

        show screen mask_icon("pj")
        pj "What about you? Have you been here long?"

        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(1.0)
        stop sound
        hide screen blinking_cursor
        cb "Long enough to know that people say more of their truth when no one knows their face."

        show screen mask_icon("pj")
        pj "That’s kind of poetic."

        show screen mask_icon("cb")
        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(1.0)
        stop sound
        hide screen blinking_cursor
        cb "Just an observation."

        $ preferences.text_cps = 0

        f_thoughts "She’s cautious, but she’s staying. Interesting."

        $ preferences.text_cps = 20

        show screen mask_icon("pj")
        pj "So, do you always go by Chat Blanc?"

        show screen mask_icon("cb")
        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(0.75)
        stop sound
        hide screen blinking_cursor
        cb "On here? Yes."
        
        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(2.0)
        stop sound
        hide screen blinking_cursor
        cb "I like the idea of a name that contradicts itself. A 'white cat' sounds innocent, but you never know when claws might come out."

        show screen mask_icon("pj")
        pj "That sounds... dramatic."

        show screen mask_icon("cb")
        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(1.0)
        stop sound
        hide screen blinking_cursor
        cb "You don’t approve?"

        # Menu choice affecting bond level
        menu:
            "Tease her":
                show screen mask_icon("cb")
                show screen blinking_cursor onlayer overlay
                play sound "audio/soft_typing_sound.mp3" loop
                $ renpy.pause(1.0)
                stop sound
                hide screen blinking_cursor
                cb "Dramatic? I prefer... theatrical."
                $ preferences.text_cps = 0
                f_thoughts "Let’s see how she reacts."
                $ preferences.text_cps = 20
                play sound "audio/soft_typing_sound.mp3" loop
                $ renpy.pause(1.0)
                stop sound
                show screen mask_icon("pj")
                pj "Oh? So you admit to putting on a show?"
                cb "Everyone does. Some just do it better."
                $ cb_pj_bond += 1

            "Deflect":
                show screen mask_icon("cb")
                show screen blinking_cursor onlayer overlay
                play sound "audio/soft_typing_sound.mp3" loop
                $ renpy.pause(1.0)
                stop sound
                hide screen blinking_cursor
                cb "Drama makes life interesting."
                $ preferences.text_cps = 0
                f_thoughts "No need to give too much away just yet."
                $ preferences.text_cps = 20
                show screen mask_icon("pj")
                pj "I guess... I can see that."
                show screen blinking_cursor onlayer overlay
                play sound "audio/soft_typing_sound.mp3" loop
                $ renpy.pause(1.0)
                stop sound
                hide screen blinking_cursor
                cb "Then you understand more than you think."

        show screen mask_icon("pj")
        pj "And what about you? Why 'Princess Justice'?"

        pj "I guess... I like the idea of standing up for what's right. Even when it's hard."

        $ preferences.text_cps = 0

        f_thoughts "Of course. Another idealist."

        $ preferences.text_cps = 20

        show screen mask_icon("cb")
        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(1.0)
        stop sound
        hide screen blinking_cursor
        cb "A noble ideal. But does Princess Justice always get to be herself?"

        $ preferences.text_cps = 0

        hide screen mask_icon

        f_thoughts "Let’s see if she answers that honestly."


        jump felix_day1_end

label felix_day1_end:
        scene room_evening_light_on 
        if felix_bridgette_bond >= 1:
            f_thoughts "Bridgette is my partner huh."
            f_thoughts "Not the worst thing in the world."
        else: 
            f_thoughts "Bridgette is my partner huh."
            f_thoughts "This couldn't get more annoying."
        if cb_pj_bond >= 1:
            f_thoughts "The new user Princess Justice will be fun to tease."
            f_thoughts "I can't wait to talk to her tomorrow."
        else: 
            f_thoughts "The new user Princess Justice is interesting."
        jump f_day2_day
