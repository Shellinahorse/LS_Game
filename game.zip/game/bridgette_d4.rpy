label b_day4_day:
    scene classroom with fade

    b_thoughts "Day 4."

    b_thoughts "I swear this week is flying by... and I’m still somehow alive."

    show felix_sketch_scaled at bridgette_center, felix_idle

    f "Morning."

    b_thoughts "Okay. Normal greeting. We got this."

    menu:
        "How should Bridgette respond today?"

        "Friendly":
            b "Morning, Felix!"
            f "You're early today."
            $ bridgette_felix_bond += 1

        "Confident (we’re evolving)":
            b "Let me guess. Already done with half the project?"
            f "Not quite. But you're close."
            $ bridgette_felix_bond += 2

        "Awkward forever":
            b "Uh... morning."
            f "Hm."
            $ bridgette_felix_bond += 0


    # Transition to working together
    b_thoughts "Working next to Felix is weirdly... calming."

    f "We should review our conclusion section."

    b "Sure."

    # Small accidental moment
    b_thoughts "Wait... is that a doodle in the corner of his notes?"

    menu:
        "Does Bridgette comment on it?"

        "Ask about the doodle":
            b "Is that... a cat?"
            f "..."
            f "Tch. A habit."
            b_thoughts "Felix Fathom... secretly a doodler?"
            $ bridgette_felix_bond += 2

        "Ignore it":
            b "Okay, moving on..."
            f "..."
            $ bridgette_felix_bond += 0

    # Post-work wrap up
    f "You're easier to work with than I expected."

    b_thoughts "Okay hold on — compliment??"

    b "Uh... thanks? You're not as scary as people say, either."

    f "Scary?"

    b "You know... tall, smart, broody energy."

    f "...Broody."

    b_thoughts "Did I actually make him laugh just now?"

    jump b_day4_night

label b_day4_night:

    scene bg_forum with fade

    b_thoughts "Okay... deep breath. Time to brain-dump everything I didn’t say out loud today."

    window hide
    show text "Phantom: 'Funny how names mean nothing... and everything.'" with dissolve
    pause 2.0
    hide text with dissolve
    window show

    b_thoughts "Phantom again."

    b_thoughts "Always lurking."

    $ preferences.text_cps = 20

    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    pj "Chat Blanc! Are you causing chaos somewhere else or just here?"

    cb "Chaos is portable. I travel light."

    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    pj "Real-life stuff has me spiraling."

    cb "Your mysterious partner again?"

    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    pj "You joke — but today I saw a doodle in his notes."

    cb "Scandalous. An artist in the wild."

    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    pj "Hey, it was a cat. Maybe he’s secretly a softie."

    cb "Careful, Princess. You're starting to sound like you're paying attention."

    $ preferences.text_cps = 0

    b_thoughts "Is it that obvious...?"

    narrator "Does Bridgette admit it?"

    $ preferences.text_cps = 20

    menu:

        "Be honest":
            pj "Maybe I am... He’s not what I expected."
            $ pj_cb_bond += 2

        "Deflect":
            pj "Everyone has layers. Even scary smart people."
            $ pj_cb_bond += 1

    cb "Layers are dangerous things. Sometimes what’s beneath isn’t ready to be seen."

    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    pj "That’s oddly deep... even for you."

    cb "Let's call it experience."

    $ preferences.text_cps = 0

    #hide screen mask_icon

    b_thoughts "Somehow... Chat Blanc feels closer tonight. Like less of a mask... and more of a person."

    jump b_day5_day
