label f_day5_day:
    scene classroom with fade

    f_thoughts "Day 5."

    f_thoughts "The final day of our project."

    f_thoughts "And... maybe the day I get my answer."

    show bridgette_sketch_scaled at bridgette_center, idle_bounce

    b "Morning, Felix!"

    f_thoughts "Bright. Confident. Different from Day 1."

    menu:
        "How does Felix feel seeing her like this?"

        "Impressed":
            f_thoughts "She's changed. Or maybe... I've just been paying attention."
            $ felix_bridgette_bond += 2

        "Neutral Observation":
            f_thoughts "Adaptable. That makes her dangerous — in the best way."
            $ felix_bridgette_bond += 1

        "Fond Amusement":
            f_thoughts "Still a little chaotic. But... that suits her."
            $ felix_bridgette_bond += 2

    f "Are you ready?"

    b "Ready as I'll ever be."

    # Presentation happens — fade for simplicity
    scene classroom with fade
    pause 1.0

    teacher "Excellent work, Felix and Bridgette."

    play sound "audio/applause.mp3" volume 0.4

    f_thoughts "We survived."

    f "You did well."

    b "Thanks... You too."

    stop sound

    f_thoughts "If I'm right... tonight changes everything."

    jump f_day5_night

label f_day5_night:

    scene bg_forum with fade

    f_thoughts "Velvet Veil."

    f_thoughts "Masks. Names. Roles."

    f_thoughts "But tonight... I want truth."

    window hide
    show text "Phantom: 'Sometimes masks are just waiting to be broken...'" with dissolve
    pause 2.0
    hide text with dissolve
    window show

    f_thoughts "Even Phantom knows."

    $ preferences.text_cps = 20

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    cb "Princess Justice."

    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Tonight feels... different."

    show screen mask_icon("pj")
    pj "It does..."

    narrator "Does Felix move toward revealing?"

    menu:

        "Directly":
            show screen mask_icon("cb")
            show screen blinking_cursor onlayer overlay
            cb "Can I ask you something real?"
            hide screen blinking_cursor
            $ cb_pj_bond += 2

        "Carefully":
            show screen mask_icon("cb")
            show screen blinking_cursor onlayer overlay
            cb "Has anyone ever told you... you remind me of someone?"
            hide screen blinking_cursor
            $ cb_pj_bond += 1

    show screen mask_icon("pj")
    pj "Depends. Am I supposed to be flattered or worried?"

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Both."

    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(2.0)
    stop sound
    hide screen blinking_cursor
    cb "I think I know who you are."

    pause 1.0

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Bridgette."

    $ preferences.text_cps = 0

    f_thoughts "Silence."

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    pj "..."

    $ preferences.text_cps = 0

    f_thoughts "I knew it."

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    pj "H-how did you—?"

    menu:
        "How does Felix explain?"

        "Softly (respect her feelings)":
            show screen mask_icon("cb")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(2.0)
            stop sound
            hide screen blinking_cursor
            cb "Your words. Your spirit. They're yours — online or off."
            $ cb_pj_bond += 2

        "Playfully (Chat Blanc energy)":
            show screen mask_icon("cb")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            hide screen blinking_cursor
            cb "Let's just say I'm very observant."
            $ cb_pj_bond += 1

        "Blunt honesty":
            show screen mask_icon("cb")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            hide screen blinking_cursor
            cb "I've suspected since Day 3."
            $ cb_pj_bond += 0

    $ preferences.text_cps = 0

    f_thoughts "Whether she accepts this or not... I said it."

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    pj "And... you're Felix."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    cb "Guilty."

    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "But still... me."

    narrator "How is the bond between them?"

    hide screen mask_icon

    menu:
        "Check bond score":
            if felix_bridgette_bond + cb_pj_bond >= 6:
                jump felix_good_ending
            elif felix_bridgette_bond + cb_pj_bond >= 4:
                jump felix_neutral_ending
            else:
                jump felix_awkward_ending
label felix_good_ending:

    scene bg_forum with fade

    $ preferences.text_cps = 0

    f_thoughts "She didn’t run."

    f_thoughts "She stayed."

    $ preferences.text_cps = 20  # Slower text for typing effect

    show screen mask_icon("pj")
    pj "I can't believe it's you... but I'm kind of glad."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Glad, huh? That’s... unexpected."

    show screen mask_icon("pj")
    pj "You thought I'd ghost you?"

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Wouldn't be the first time someone ran from the real me."

    show screen mask_icon("pj")
    pj "I'm not just anyone."

    $ preferences.text_cps = 0

    f_thoughts "No. She's not."

    $ preferences.text_cps = 20 

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Bridgette Shah. Princess Justice."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Turns out... I like both versions."

    show screen mask_icon("pj")
    pj "Turns out you're a better partner than I thought."
    
    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Careful. Keep complimenting me like that and I might get attached."

    show screen mask_icon("pj")
    pj "Might?"

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Too late."

    $ preferences.text_cps = 0

    f_thoughts "For once... honesty feels easy."

    $ preferences.text_cps = 20

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Same time tomorrow?"

    show screen mask_icon("pj")
    pj "Wouldn't miss it."

    hide screen mask_icon

    return
label felix_neutral_ending:

    scene bg_forum with fade

    f_thoughts "She didn't run."

    f_thoughts "But there's hesitation."

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    pj "This is... a lot to process."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "I understand."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Believe it or not... I didn't plan for this either."

    show screen mask_icon("pj")
    pj "Yeah... I just need a little time."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Take all the time you need."

    $ preferences.text_cps = 0

    f_thoughts "If this is all I get — it’s still more than I expected."

    $ preferences.text_cps = 20

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "I'll be here."

    show screen mask_icon("pj")
    pj "I'm not disappearing."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Good."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Neither am I."

    $ preferences.text_cps = 0

    f_thoughts "Some connections... don’t need to be rushed."

    hide screen mask_icon

    return
label felix_awkward_ending:

    scene bg_forum with fade

    $ preferences.text_cps = 0

    f_thoughts "Silence."

    f_thoughts "Not anger."

    f_thoughts "Worse. Uncertainty."

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    pj "I... I need time."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "That's fair."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "I didn’t mean to blindside you."

    show screen mask_icon("pj")
    pj "It's not that I hate you or anything it’s just—"

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Complicated."

    show screen mask_icon("pj")
    pj "...Yeah."

    $ preferences.text_cps = 0

    f_thoughts "Too soon."

    f_thoughts "Too real."

    $ preferences.text_cps = 20

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "I'll back off."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "But the mask is still here. If you want it."

    show screen mask_icon("pj")
    pj "Maybe... someday."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Take care, Princess Justice."

    show screen mask_icon("pj")
    pj "You too, Chat Blanc."

    $ preferences.text_cps = 0

    f_thoughts "Even if tonight wasn't perfect... she knows."

    f_thoughts "And somehow... that’s enough."

    hide screen mask_icon

    return
