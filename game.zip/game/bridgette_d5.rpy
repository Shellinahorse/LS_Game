label b_day5_day:
    scene classroom with fade

    b_thoughts "Day 5."

    b_thoughts "Presentation day."

    b_thoughts "I'm supposed to be nervous about public speaking — not about... him."

    show felix_sketch_scaled at bridgette_center, felix_idle

    f "Ready?"

    b_thoughts "Always so calm."

    menu:
        "How does Bridgette feel right now?"

        "Surprisingly Calm":
            b "I think so. We worked hard."
            $ bridgette_felix_bond += 1

        "Lowkey Panicking":
            b "Uhm... as ready as I'll ever be."
            $ bridgette_felix_bond += 0

        "Playful (growth!)":
            b "Ready to make everyone else look bad."
            f "Bold of you."
            $ bridgette_felix_bond += 2

    # Presentation happens (SKIPPING DETAILS FOR NOW)

    teacher "Excellent work, Felix and Bridgette."

    play sound "audio/applause.mp3" volume 0.4

    b_thoughts "We survived."

    f "You did well."

    b "Thanks. You too."

    stop sound

    #Felix sprite is supposed to smile here, but I do not have a sprite representing that yet. 
    #f_thoughts "(small smile)"

    jump b_day5_night

label b_day5_night:

    scene bg_forum with fade

    $ preferences.text_cps = 0

    b_thoughts "Velvet Veil feels... different tonight."

    b_thoughts "Almost like I've known Chat Blanc forever."

    window hide
    show text "Phantom: 'Masks were never meant to last forever...'" with dissolve
    pause 2.0
    hide text with dissolve
    window show

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "Hey. You there?"

    show screen mask_icon("cb")
    cb "Always, Princess."

    cb "But tonight feels different."

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "Yeah..."

    menu:
        "Does Bridgette push toward honesty?"

        "Yes — Drop a hint":
            show screen mask_icon("pj")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            hide screen blinking_cursor
            pj "Weird question... but do you ever feel like you've already met someone here?"
            $ pj_cb_bond += 2

        "No — Stay playful":
            show screen mask_icon("pj")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            hide screen blinking_cursor
            pj "Maybe it's just me being dramatic again."
            $ pj_cb_bond += 0

    show screen mask_icon("cb")
    cb "Sometimes... truth is waiting to be said out loud."

    cb "Princess Justice..."

    $ preferences.text_cps = 0

    f_thoughts "I've known for a while, haven't I?"

    $ preferences.text_cps = 20

    cb "Bridgette."

    pause 1.0

    hide screen mask_icon

    $ preferences.text_cps = 0

    b_thoughts "Wait. What."

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "What did you just—?"

    show screen mask_icon("cb")
    cb "It's you, isn't it?"

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "..."

    menu:
        "How does Bridgette react?"

        "Panic (default reaction)":
            show screen mask_icon("pj")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            hide screen blinking_cursor
            pj "H-how did you—?"
            $ pj_cb_bond += 0

        "Play it cool (confidence arc)":
            show screen mask_icon("pj")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            hide screen blinking_cursor
            pj "Took you long enough."
            $ pj_cb_bond += 2

        "Silent (processing)":
            show screen mask_icon("pj")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            hide screen blinking_cursor
            pj "..."
            $ pj_cb_bond += 1

    show screen mask_icon("cb")
    cb "It's okay."

    cb "You're not the only one who's surprised."

    cb "Felix."

    pause 1.0

    $ preferences.text_cps = 0

    b_thoughts "FELIX???"

    b_thoughts "My partner... Chat Blanc... same person???"

    "Final Reaction — Determined by Bond Levels"

    $ preferences.text_cps = 20

    hide screen mask_icon
    menu:
        "Check bond score":
            if bridgette_felix_bond + pj_cb_bond >= 6:
                jump bridgette_good_ending
            elif bridgette_felix_bond + pj_cb_bond >= 4:
                jump bridgette_neutral_ending
            else:
                jump bridgette_awkward_ending

label bridgette_good_ending:

    scene bg_forum with fade

    $ preferences.text_cps = 0

    b_thoughts "Felix."

    b_thoughts "Chat Blanc."

    b_thoughts "The same person. And... weirdly? That makes sense."

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "I can't believe it's you... but I'm kind of glad."

    show screen mask_icon("cb")
    cb "Glad, huh? I was worried you'd log off forever."

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "Please. Like you could get rid of me that easily."

    show screen mask_icon("cb")
    cb "Stubborn in every timeline, I see."

    $ preferences.text_cps = 0

    b_thoughts "I should be freaking out. But... I'm not."

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "Honestly? Talking to you here felt easy. Safe."

    show screen mask_icon("cb")
    cb "That's how I felt too."

    cb "Maybe it's less about the mask... and more about who we are underneath."

    $ preferences.text_cps = 0

    b_thoughts "I don't know what happens next... but I want to find out."

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "So... same time tomorrow, my kitty cat?"

    show screen mask_icon("cb")
    cb "Wouldn't miss it for the world, m'lady."

    hide screen mask_icon

    return


label bridgette_neutral_ending:

    #scene bg_forum with fade

    $ preferences.text_cps = 0

    b_thoughts "Felix."

    b_thoughts "Chat Blanc."

    b_thoughts "Part of me saw this coming. Part of me still can't believe it."

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "This is... a lot to process."

    show screen mask_icon("cb")
    cb "Understandable."

    cb "I didn't expect this either."

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "It's not bad, it's just... weird?"

    show screen mask_icon("cb")
    cb "Weird isn't always bad."

    $ preferences.text_cps = 0

    b_thoughts "He's right. But still..."

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "I guess I just need time to figure out how I feel."

    show screen mask_icon("cb")
    cb "Take all the time you need."

    cb "I'll still be here."

    $ preferences.text_cps = 0

    hide screen mask_icon

    b_thoughts "Somehow, knowing that makes this a little easier."

    return


label bridgette_awkward_ending:

    #scene bg_forum with fade

    $ preferences.text_cps = 0

    b_thoughts "Felix."

    b_thoughts "Chat Blanc."

    b_thoughts "Of all people... it had to be him."

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "I... I need time."

    show screen mask_icon("cb")
    cb "I get it."

    cb "This wasn't exactly in my plan either."

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "It's not that I hate you or anything it's just—"

    show screen mask_icon("cb")
    cb "Complicated."

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "...Yeah."

    $ preferences.text_cps = 0

    b_thoughts "My heart's racing for all the wrong reasons."

    b_thoughts "Are they really the same person?!"

    b_thoughts "He's got to be lying to me. He's probably known this whole time and took me for a fool."

    $ preferences.text_cps = 20

    show screen mask_icon("cb")
    cb "I'll back off for now."

    cb "But... if you ever want to talk — the mask's always here."

    $ preferences.text_cps = 0

    b_thoughts "Maybe... maybe one day."

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(2.0)
    stop sound
    hide screen blinking_cursor
    pj "Goodnight, Chat Blanc."

    show screen mask_icon("cb")
    cb "Goodnight, Princess Justice."

    hide screen mask_icon

    return



