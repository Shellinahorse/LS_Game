#Bridgette Route Flags
default bridgette_felix_bond = 0
default pj_cb_bond = 0

#Felix Route flags
default felix_bridgette_bond = 0
default cb_pj_bond = 0