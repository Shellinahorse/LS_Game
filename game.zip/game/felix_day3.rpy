label felix_day3_day:
    scene classroom with fade

    f_thoughts "Day 3."

    f_thoughts "Bridgette Dupain-Cheng. Less jumpy today. Progress."

    show bridgette_sketch_scaled at bridgette_center, idle_bounce

    b "Morning, Felix."

    f_thoughts "She spoke first."

    menu:
        "How does Felix feel about this?"

        "Mildly Impressed":
            f_thoughts "Didn't think she'd warm up this fast."
            $ felix_bridgette_bond += 2

        "Curious":
            f_thoughts "Comfort breeds honesty. Interesting."
            $ felix_bridgette_bond += 1

        "Unfazed":
            f_thoughts "Routine is settling in. Good."
            $ felix_bridgette_bond += 0

    f "Ready to start?"

    b "Yep."

    # Felix working... but observing
    f_thoughts "Focused today. Fewer stammers."

    menu:
        "Does Felix ask something personal?"

        "Yes — Direct Question":
            f "Is this project stressing you out?"
            b "Huh? Oh... a little."
            f "You're handling it fine."
            $ felix_bridgette_bond += 1

        "No — Stay Quiet":
            f_thoughts "Better to let her work in peace."
            $ felix_bridgette_bond += 0

    f_thoughts "Still... sometimes I catch glimpses of something else beneath her quiet."

    f_thoughts "Almost reminds me of... someone."

    jump f_day3_night

label f_day3_night:
    scene bg_forum with fade

    window hide
    show text "Phantom: 'Even masks cast shadows when worn too long.'" with dissolve
    pause 2.0
    hide text with dissolve
    window show

    f_thoughts "Phantom again."

    f_thoughts "Always lurking. Always vague."

    $ preferences.text_cps = 20

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Evening, Princess Justice. Still surviving reality?"

    show screen mask_icon("pj")
    pj "Barely."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Then you've come to the right haunt."

    $ preferences.text_cps = 0

    f_thoughts "There's honesty in her words here... sharper than in daylight."

    $ preferences.text_cps = 20

    menu:
        "How does Chat Blanc treat her tonight?"

        "Encourage Vulnerability":
            show screen mask_icon("cb")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            hide screen blinking_cursor
            cb "Tell me everything. The world out there can wait."
            $ cb_pj_bond += 2

        "Keep it Light":
            show screen mask_icon("cb")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            hide screen blinking_cursor
            cb "Drama, secrets, chaos... the usual, I assume?"
            $ cb_pj_bond += 1

    show screen mask_icon("pj")
    pj "You're impossible."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Impossible is far more fun."

    $ preferences.text_cps = 0

    hide screen mask_icon

    f_thoughts "But fun has a price."

    f_thoughts "And sometimes... it's truth."

    jump f_day4_day



