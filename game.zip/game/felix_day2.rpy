label f_day2_day:
    scene classroom with fade
    f_thoughts "Day 2 of this group project."

    f_thoughts "Bridgette Dupain-Cheng. Top of the class. Always prepared. Always quiet."

    f_thoughts "Until she has to speak to me."

    # Bridgette "runs in" from left side
    show bridgette_sketch_scaled at offscreenleft
    with dissolve

    pause 0.2
    play sound "audio/running_downstairs.mp3" volume 0.3
    pause 1.0
    show bridgette_sketch_scaled:
        moveacross
    with dissolve

    stop sound
    #show bridgette_sketch_scaled at bridgette_center, idle_bounce

    f "Morning, Bridgette."

    f_thoughts "There it is again... That pause. She's nervous around me."

    #Bridgette auto-responds based on her personality today (because we are in Felix's route right now)
    b "M-Morning..."

    f_thoughts "Cute."

    #Now give the player (as Felix) agency in how to interpret it:
    menu:
        "How does Felix feel?"

        "Amused":
            f_thoughts "She's trying so hard to look serious. It's... kind of endearing."
            $ felix_bridgette_bond += 2

        "Indifferent":
            f_thoughts "Nerves or not — as long as she does her work, it doesn't matter."
            $ felix_bridgette_bond += 0

        "Curious":
            f_thoughts "Why is someone like her so flustered around me?"
            $ felix_bridgette_bond += 1

    jump f_day2_night


label f_day2_night:

    $ preferences.text_cps = 0

    scene bg_forum with fade
    #play music "forum_theme.mp3" fadein 1.0

    f_thoughts "Night falls, and I log in as Chat Blanc... It’s quieter here."

    #Brief phantom foreshadowing for plot later
    window hide
    show text "Phantom: 'Funny thing about masks... They slip fastest when the heart gets involved.'" with dissolve
    pause 2.0
    hide text with dissolve
    window show

    f_thoughts "Phantom again."

    f_thoughts "Always watching. Always stirring the pot."

    f_thoughts "Some people fear them. I watch them."

    $ preferences.text_cps = 20

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Princess Justice, are you there?"

    show screen mask_icon("pj")
    pj "Always. The late hours are for speaking our truths when the world is asleep."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "I was hoping we'd catch up after today. There's something about your messages that brightens this digital night."

    show screen mask_icon("pj")
    pj "You're too kind... even if I'm not meant to show it."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Some truths, though, are meant to shine even in darkness."

    $ preferences.text_cps = 0

    f_thoughts "I can hardly believe I let myself care this much."

    narrator "How should Chat Blanc respond?"

    $ preferences.text_cps = 20

    menu:
        
        "Playfully tease":
            show screen mask_icon("cb")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            hide screen blinking_cursor
            cb "Don't get all sappy on me, Princess. I know you secretly relish a touch of chaos."
            $ cb_pj_bond += 2
            
        "Express genuine concern":
            show screen mask_icon("cb")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            hide screen blinking_cursor
            cb "I worry about you, you know? Even through these screens, I sense your struggles."
            $ cb_pj_bond += 3
            
        "Keep it cool":
            show screen mask_icon("cb")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            hide screen blinking_cursor
            cb "Just another night of banter, right? Let’s keep it light."
            $ cb_pj_bond += 1

    show screen mask_icon("pj")
    pj "You're still a mystery to me, Chat Blanc."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "Mysteries keep things interesting."

    show screen mask_icon("cb")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    cb "But riddles... riddles beg to be solved."

    $ preferences.text_cps = 0 #Reset text speed

    hide screen mask_icon

    f_thoughts "And every night, I wonder if solving her is worth risking being seen."

    jump felix_day3_day

    

    
    
