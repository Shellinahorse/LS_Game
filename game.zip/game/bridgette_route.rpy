#File created by me (Usman)

# Bridgette's route
label bridgette_route_start:
    #show bridgette at bridgette_center#Replacing this with sketch for now
    show bridgette_sketch_scaled at bridgette_center
    b "You chose me! Let's go on an adventure."
    jump classroom_scene

label classroom_scene:
        stop music fadeout 2.0
        #scene school_science_lab_day01
        scene classroom

        teacher "Today will be a working session. You will be paired with a partner and you'll present your findings at the end of the week."
        b_thoughts "That doesn't sound too bad..."
        teacher "Felix and Bridgette, you’ll be working together for this assignment."

        b_thoughts "Oh no... Why did this happen? I have to work with him..."# Bridgette's internal thoughts and reactions
        show felix_sketch_scaled at felix_center, felix_idle, felix_idle_shift
        f "..."  

        # FIRST CHOICE!!!
        menu:
            "How does Bridgette react?"
            "Excited":
                b "Oh! That’s great! I mean, I—uh, let’s do our best!" 
                f "..."  # Felix raises an eyebrow, confused.
                # Continue to the group project scene
                $ bridgette_felix_bond += 2
                jump project_scene
            "Casual":
                b "Alright, let’s get started."
                f "..."  # Felix nods, appreciating her professionalism.
                jump project_scene
            "Shy & Awkward":
                b "Uhm… yeah… okay…"
                f "..."  # Felix looks at her, unsure.
                $ bridgette_felix_bond += 1
                jump project_scene

label project_scene:
        # Some progress with the project (can be expanded later)
        teacher "Alright, get to work!"
        b "I-I’ll take care of the research, if that’s alright with you..."
        f "Sounds good."
        
        #Narrator and Bell sound effect here?

        play music "audio/tower_clock_chime.mp3" volume 0.3 
        teacher "That's it for today. Remember to keep working on your projects!"
        stop music fadeout 2.0
        b "I'll see you later! ...And he's already gone."
        menu:
            "What should Bridgette do?"
            "Chase after him":
                b "It's okay. I can still catch up!"
                jump hallway_scene
            "Leave it.":
                b "But what if I never see him again? Then I'll regret this moment forever!"
                jump hallway_scene

label hallway_scene:
        scene auditorium_outside_evening
        b "Hey Felix!"
        show felix_sketch_scaled at felix_center, felix_idle
        f "..."
        b_thoughts "He actually listened! Alright, now all I have to do is ask him to study with me later."
        b "I was wondering if you wanted to stick--study together? I mean, you can totally decline if you want to, but I thought, I figured I'd ask because we are partners, but you're really smart and probably don't need my help, but two brains are better than one, and--"
        f "...Thanks, but I already have plans today."
        $ renpy.pause(0.5)
        play sound "audio/running_downstairs.mp3" volume 0.2
        show felix_sketch_scaled at walk_off_left
        $ renpy.pause(1.0)
        hide felix_sketch_scaled
        stop sound
        b "O-oh..."
        #Felix's plans are to go on the forum
        #Have two background characters talking about the online forum, from Bridgette's perspective
        "Kevin" "Did you see the new thread on Velvet Veil last night? Someone called 'Phantom' posted a riddle, and no one can solve it!"
        "Victor" "I know! And that user, Chat Blanc, had the wittiest reply. He's so mysterious."
        jump night_forum #Transition to night-time forum scene

# The night-time anonymous forum interaction
#Velvet: #750851
label night_forum:
        # Scene transition to the online forum
        
        scene room_evening_light_on
        b "Everybody's been talking about this online forum, Velvet Veil. Apparently it's anonymous."
        b "Is that even possible? No real names, no faces, just words on a screen."
        b "Maybe I should try logging on...just this once."

        scene bg_forum#Scene replaces everything that is visible. Show replaces only the background image.
        with fade

        b "Enter a username...?"
        b "If it's supposed to be anonymous, I'll think of something creative."
        b "Lady Chaos....no. Panic? Still revealing too much. I don't want something negative anyways. This is my opportunity to be someone new, someone confident!"
        b "And I have the perfect name."
        # Bridgette and Felix are on the forum as their alter egos
        # Princess Justice (Bridgette) and Chat Blanc (Felix)
        #show b at bridgette_center

        b "(What am I even supposed to say? Just type something, Bridgette.)"

        $ preferences.text_cps = 20  # Slower text for typing effect

        #$ type_speak(pj, "Hi. Is anyone here?")
        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(1.0)
        stop sound
        hide screen blinking_cursor
        show screen mask_icon("pj")
        pj "Hi. Is anyone here?"

        #A moment of silence before a new message appears.
        show screen mask_icon("cb")
        a_cb "Welcome to the Velvet Veil, Princess Justice."

        $ preferences.text_cps = 0  #Reset typing effect for the thoughts

        b_thoughts "Someone responded! What do I say now?"

        $ preferences.text_cps = 20
        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(1.0)
        stop sound
        hide screen blinking_cursor

        show screen mask_icon("pj")
        pj "Oh, um… hi?"

        $ preferences.text_cps = 0  
        b_thoughts "Ugh. That was lame."
        $ preferences.text_cps = 20  

        show screen mask_icon("cb")
        a_cb "A new username… You're new here, aren't you?"

        show screen mask_icon("pj")
        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(1.0)
        stop sound
        hide screen blinking_cursor

        pj "Yeah. I guess I'm just… curious about this place."
        
        show screen mask_icon("cb")
        cb "Curiosity is a good thing. Some say it’s dangerous, but I find it refreshing."

        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(1.0)
        stop sound
        hide screen blinking_cursor

        show screen mask_icon("pj")
        pj "What about you? Have you been here long?"

        show screen mask_icon("cb")
        cb "Long enough to know that people say more of their truth when no one knows their face."

        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(2.0)
        stop sound
        hide screen blinking_cursor

        show screen mask_icon("pj")
        pj "That’s kind of poetic."

        show screen mask_icon("cb")
        cb "Just an observation."

        $ preferences.text_cps = 0  #Reset typing effect for the thoughts
        b_thoughts "Speaking of observations, his username is kind of odd."
        $ preferences.text_cps = 20

        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(2.0)
        stop sound
        hide screen blinking_cursor

        show screen mask_icon("pj")
        pj "So, do you always go by Chat Blanc?"

        show screen mask_icon("cb")
        cb "On here? Yes."

        cb "I like the idea of a name that contradicts itself. A 'white cat' sounds innocent, but you never know when claws might come out."

        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(1.0)
        stop sound
        hide screen blinking_cursor

        show screen mask_icon("pj")
        pj "That sounds... dramatic."
        
        show screen mask_icon("cb")
        cb "You don’t approve?"

        hide screen mask_icon
        menu:
            "Tease him":
                show screen blinking_cursor onlayer overlay
                play sound "audio/soft_typing_sound.mp3" loop
                $ renpy.pause(1.0)
                stop sound
                hide screen blinking_cursor

                show screen mask_icon("pj")
                pj "What, are you some kind of masked villain?"

                show screen mask_icon("cb")
                cb "Maybe. Or maybe I just like to keep people guessing."

                show screen blinking_cursor onlayer overlay
                play sound "audio/soft_typing_sound.mp3" loop
                $ renpy.pause(1.0)
                stop sound
                hide screen blinking_cursor

                show screen mask_icon("pj")
                pj "Mysterious and dramatic. Quite the combination."

                show screen mask_icon("cb")
                cb "And yet, you’re still talking to me."
                $ pj_cb_bond += 1

            "Be sincere":
                show screen blinking_cursor onlayer overlay
                play sound "audio/soft_typing_sound.mp3" loop
                $ renpy.pause(1.0)
                stop sound
                hide screen blinking_cursor

                show screen mask_icon("pj")
                pj "No, I think it’s interesting."

                show screen mask_icon("cb")
                cb "Interesting how?"

                show screen blinking_cursor onlayer overlay
                play sound "audio/soft_typing_sound.mp3" loop
                $ renpy.pause(1.0)
                stop sound
                hide screen blinking_cursor

                show screen mask_icon("pj")
                pj "It makes me wonder what you’re hiding."

                show screen mask_icon("cb")
                cb "Ah, but that’s the point, isn’t it? A name reveals what you want it to."
                $ pj_cb_bond += 2

        show screen mask_icon("cb")
        cb "And what about you? Why 'Princess Justice'?"

        show screen blinking_cursor onlayer overlay
        play sound "audio/soft_typing_sound.mp3" loop
        $ renpy.pause(2.0)
        stop sound
        hide screen blinking_cursor

        show screen mask_icon("pj")
        pj "I guess... I like the idea of standing up for what's right. Even when it's hard."

        show screen mask_icon("cb")
        cb "A noble ideal. But does Princess Justice always get to be herself?"

        $ preferences.text_cps = 0

        b_thoughts "(What does he mean by that...?)"
        hide screen mask_icon
        
        jump bridgette_day1_end

label bridgette_day1_end:
        scene room_evening_light_on
        if bridgette_felix_bond >= 1:
            b_thoughts "I can't wait to see Felix again!"
            b_thoughts "I might even have a chance!"
        else: 
            b_thoughts "Felix is amazing."
            b_thoughts "I feel like my crush is a lost cause..."
        if pj_cb_bond >= 1:
            b_thoughts "The new user Chat Blanc was so flirty!"
            b_thoughts "...It's not unwelcome."
        else: 
            b_thoughts "The new user Chat Blanc..."
            b_thoughts "I can't figure him out."
        jump b_day2_day