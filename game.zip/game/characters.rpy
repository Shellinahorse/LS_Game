#File created by me (Usman)

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define b = Character("Bridgette", color="#e37b98", what_font="fonts/Quicksand/static/Quicksand-Bold.ttf", what_size=30)#color="#242a47" is too dark
define b_thoughts = Character("Bridgette", color="#e37b98", what_font="fonts/Quicksand/static/Quicksand-Bold.ttf", what_color="#e3c1c8", what_italic=True, what_size=30)

define a_pj = Character("???", color="#f21c1e")
define pj = Character("Princess Justice", color="#f21c1e", what_font="fonts/IBMPlexMono-Medium.ttf", what_size=28)#what_cps=10

define f = Character("Felix", color="#d7d6a5", what_font="fonts//Quicksand/static/Quicksand-Regular.ttf", what_size=30)
define f_thoughts = Character("Felix", color="#d7d6a5", what_font="fonts//Quicksand/static/Quicksand-Regular.ttf", what_color="#b6d7a8", what_italic=True, what_size=30)

define a_cb = Character("???", color="#ffffff", what_font="fonts/IBMPlexMono-Medium.ttf", what_size=28)
define cb = Character("Chat Blanc", color="#ffffff", what_font="fonts/IBMPlexMono-Medium.ttf", what_size=28)#what_cps=10

define bridgette_center = Transform(xalign=0.5, yalign=0.5)
define felix_center = Transform(xalign=0.5, yalign=0.5)
#image bridgette_sketch_scaled = im.Scale("images/Bridgette Sketch.png", 600, 800)
image bridgette_sketch_scaled = im.Scale("images/bridgette_sprite.webp", 850, 1100)
#image felix_sketch_scaled = im.Scale("images/Chopped_Felix.png", 300, 800)
image felix = "images/felix_sprite.webp"
image felix_sketch_scaled = im.Scale("images/felix_sprite.webp", 850, 1100)

define teacher = Character("Madame Bustier", color="#4f4f4f")
define narrator = Character(None, what_color="#158BD5", what_size = 30)

image classroom = im.Scale("images/school_science_lab_day01.jpg", config.screen_width, config.screen_height)
image school_evening = im.Scale("images/school_evening.jpg", config.screen_width, config.screen_height)
image bg_forum = im.Scale("images/forum.jpg", config.screen_width, config.screen_height)

transform offscreenbottomleft: 
    xpos 0.0 xanchor 1.0 ypos 2.0 yanchor 1.0

define leftside = MoveTransition(
    dela = 0.3,
    enter=offscreenbottomleft,
    leave=offscreenbottomleft,
    old=False, 
    layers=['master'],
    time_warp=ease,
    enter_time_warp=None,
    leave_time_warp=None
)

transform offscreenleft:
    xpos -0.5 yalign 1.0

transform moveacross:
    linear 0.5 xpos 0.5 xanchor 0.5 yalign 1.0

transform walk_off_left:
    linear 1.0 xpos -0.5

transform idle_bounce:
    linear 1.0 zoom 1.05
    linear 1.0 zoom 1.0
    repeat

transform idle_shift:
    linear 1.0 xoffset -5
    linear 1.0 xoffset 5
    repeat

transform felix_idle:
    linear 3.0 zoom 1.01
    linear 3.0 zoom 1.0
    repeat

transform felix_idle_shift:
    linear 1.5 xoffset -2
    linear 1.5 xoffset 2
    repeat

#transform blink_cursor:
#    alpha 1.0
#    linear 0.5 alpha 0.0
#    linear 0.5 alpha 1.0
#    repeat

transform blink_cursor:
    alpha 1.0
    pause 0.3
    linear 0.2 alpha 0.0
    pause 0.1
    linear 0.2 alpha 1.0
    repeat

'''init python:

    def type_speak(who, line, delay=1.0, sound="audio/soft_typing_sound.mp3", cps=20):
        renpy.play(sound, loop=True)
        renpy.pause(delay)
        renpy.stop(sound)
        preferences.text_cps = cps
        renpy.say(who, line)
        preferences.text_cps = 0

init python:

    def run_in(character_image, soundfile="audio/running_downstairs.mp3", volume=0.3, duration=0.5):
        renpy.show(character_image, at_list=[offscreenleft])
        renpy.with_statement(dissolve)
        renpy.pause(0.2)
        renpy.play("sound", soundfile, volume=volume)
        renpy.show(character_image, at_list=[moveacross_center])
        renpy.with_statement(dissolve)
        renpy.pause(duration)
        renpy.stop("sound")'''