label b_day2_day:
    scene classroom with fade
    #play music "school_theme.mp3" fadein 1.0

    b_thoughts "Okay... Day 2 of working with Felix."
    b_thoughts "Yesterday wasn’t a total disaster. I didn’t stutter that badly, right?"

    show felix_sketch_scaled at bridgette_center, felix_idle, felix_idle_shift
    f "Morning, Bridgette."

    b_thoughts "HE initiated??"
    b_thoughts "Is this a trap?? No. Be normal. Be cool."

    menu:
        "How should Bridgette respond?"
            
        "Friendly":
            b "Good morning, Felix! Ready to tackle this project?"
            f "Of course."
            
        "Awkward":
            b "M-Morning..."
            f "..."
            
        "Cool & Detached":
            b "Morning."
            f "..."

    teacher "Alright, pair up with your partners."

    b_thoughts "Time to look like a functioning human being."

    f "I was thinking we could split the research today."

    b "That works for me."

    b_thoughts "Why is he so effortlessly calm? Meanwhile, I’m over here losing it internally."

        #scene bg library with dissolve
        #play music "soft_focus.mp3"
    $ window_style = style.window_emotion
    
    b_thoughts "Working next to him is... weirdly nice."

    b "Um, thanks for working with me."

    f "Huh? Of course."

    $ window_style = style.window_emotion

    #Small talk opportunity
    menu:
        "Should Bridgette try small talk?"
            
        "Yes — talk about hobbies":
            b "By the way... do you have any hobbies outside of school stuff?"
            f "Hobbies? Hm... I fence."
            b_thoughts "Of course he does. Tall. Smart. Fights with swords. What am I even doing here."

            f "What about you?"

            menu:
                "Be Honest":
                    b "I draw... sometimes."
                    f "Really? I'd like to see it sometime."
                    $ bridgette_felix_bond += 2

                "Downplay it":
                    b "Nothing that cool. Just stuff."
                    f "Hm. I doubt that."
                    $ bridgette_felix_bond += 1
            
        "No — stay focused on work":
            b "Alright, let’s focus on the notes."
            f "Efficient. I respect that."
            $ bridgette_felix_bond += 0

    play music "audio/tower_clock_chime.mp3" volume 0.3
    teacher "That's it for today."
    stop music fadeout 2.0
    b_thoughts "Somehow... that wasn’t a complete disaster."

    play sound "audio/running_downstairs.mp3" volume 0.2
    show felix_sketch_scaled at walk_off_left
    $ renpy.pause(1.0)
    hide felix_sketch_scaled
    stop sound
        
    jump b_day2_night


label b_day2_night:
    scene bg_forum with fade

    b_thoughts "Finally... the one place I don't feel like a socially malfunctioning robot."

    b_thoughts "Velvet Veil feels so different from real life. Nobody stares. Nobody expects anything."

    #Phantom post flashes briefly before Chat Blanc arrives
    window hide
    show text "Phantom: 'Trust is a fragile thing in the dark.'" with dissolve
    pause 1.5
    show text "Phantom: 'Careful who you tell your secrets to, Princess.'" with dissolve
    pause 2.0
    hide text with dissolve
    window show

    b_thoughts "Whoa... was that directed at me?"

    b_thoughts "No way. It's just a coincidence... right?"

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor 
    pj "Chat Blanc! You there?"

    show screen mask_icon("cb")
    cb "Always, Princess Justice. Awaiting your latest chaos."

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "It's not chaos... it's just... group projects."

    show screen mask_icon("cb")
    cb "Ah. Troubles with your mysterious class partner?"

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "Maybe... He’s super smart but kind of hard to read."

    show screen mask_icon("cb")
    cb "Ah. The classic mortal enemy."

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "Mine has a face though. Smart, intimidating, kind of... effortlessly cool. It's annoying."

    show screen mask_icon("cb")
    cb "Sounds like someone’s got a crush."

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "I do not."

    show screen mask_icon("cb")
    cb "Denial. A powerful force."

    menu:
        "How should Princess Justice respond?"
        
        "Admit it... a little":
            show screen mask_icon("pj")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            hide screen blinking_cursor
            pj "Maybe... he's kind of impressive. Just don't tell him I said that."
            show screen mask_icon("cb")
            cb "My lips are sealed, Princess."
            $ pj_cb_bond += 1
        
        "Deflect":
            show screen mask_icon("pj")
            show screen blinking_cursor onlayer overlay
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            hide screen blinking_cursor
            pj "I don't even know him that well!"
            show screen mask_icon("cb")
            cb "Sometimes strangers are easier to figure out than the people we see every day."
            $ pj_cb_bond += 0

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "Talking to you is just... easier."

    show screen mask_icon("cb")
    cb "That's the beauty of Velvet Veil. No masks... except the ones we choose."

    hide screen mask_icon

    $ preferences.text_cps = 0

    jump b_day3_day

