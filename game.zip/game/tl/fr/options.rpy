﻿# TODO: Translation updated at 2025-02-24 20:15

translate fr strings:

    # game/options.rpy:15
    old "LS_Game"
    new ""

    # game/options.rpy:35
    old "Play as Bridgette or Felix as they navigate their normal lives at school and their secret lives online."
    new ""

