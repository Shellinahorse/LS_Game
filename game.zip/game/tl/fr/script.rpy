﻿# TODO: Translation updated at 2025-02-24 20:15

# game/script.rpy:39
translate fr bridgette_route_882cac5c:

    # b "You chose me! Let's go on an adventure."
    b "Tu m'as choisie ! Allons vivre une aventure."

# game/script.rpy:44
translate fr felix_route_4f5a0b3c:

    # f "You chose me. Let's see where this takes us."
    f "Tu m'as choisi. Voyons où cela nous mène."

translate fr strings:

    # game/script.rpy:24
    old "Choose your character:"
    new "Choisis ton personnage. "

    # game/script.rpy:24
    old "Bridgette"
    new "Bridgette"

    # game/script.rpy:24
    old "Felix"
    new "Felix"

