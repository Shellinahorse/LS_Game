#Testing a possible turn based battle system

'''
$ player_max_hp = 10
$ player_hp = player_max_hp

$ enemy_max_hp = 6
$ enemy_hp = enemy_max_hp

while player_hp > 0:
    #Player's Turn
    menu:
        "Light Attack":
            if(d10 >= 8):
                $ player_attack_value = d4 + d6
                $ enemy_hp -= player_attack_value
                "Critical Hit! [player_attack_value] damage!"
            else:
                $ enemy_hp -= d4
                "Dealt [d4] damage! The enemy has [enemy_hp] hp!"
            if enemy_hp <= 0
                "The enemy has been defeated!"
                jump simple_end
        "Heavy Attack":
            if d10 >= 9:
                $ player_attack_value = (d6 + d4)*2
                $ enemy_hp -= player_attack_value
                "Critical Hit! You hit for [player_attack_value] damage!"
            elif d10 >= 5:
                $ player_attack_value = d6 + 2
                $ enemy_hp -= player_attack_value
                "Strong hit! Enemy took [player_attack_value] damage!"
        "Don't Attack":
            "You don't attack..."
    
    #Enemy Turn
#init python:
#    Character 

#Helper functions

label dice_roll:
    $ d4 = renpy.random.randint(1, 4)
    $ d6 = renpy.random.randint(1, 6)
    $ d10 = renpy.random.randint(1, 10)
    $ d20 = renpy.random.randint(1, 20)
    return
'''