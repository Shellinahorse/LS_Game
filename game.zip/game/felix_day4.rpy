label f_day4_day:
    scene classroom with fade

    f_thoughts "Day 4."

    f_thoughts "Bridgette Shah."

    f_thoughts "Still surprising me in small ways."

    show bridgette_sketch_scaled at bridgette_center, idle_bounce

    b "Morning, Felix!"

    f_thoughts "No hesitation this time."

    menu:
        "How does Felix react internally?"

        "Amused":
            f_thoughts "Progress. Who knew she'd adapt so quickly."
            $ felix_bridgette_bond += 2

        "Neutral":
            f_thoughts "Routine is comfort. I understand that."
            $ felix_bridgette_bond += 0

        "Curious":
            f_thoughts "She's warming up. But is that her real self?"
            $ felix_bridgette_bond += 1

    f "You're early."

    b "Trying to be more efficient today."

    f "I can respect that."

    # Working together — Felix starts to notice more
    f_thoughts "She's more focused today."

    f_thoughts "Less fidgeting. Less rambling."

    f_thoughts "But still that same... unpredictability."

    # Doodle moment from Felix's POV
    b "Is that... a cat?"

    f "..."

    f_thoughts "She noticed."

    menu:
        "How does Felix respond?"

        "Admit it directly":
            f "Old habit."
            $ felix_bridgette_bond += 2

        "Brush it off":
            f "It's nothing."
            $ felix_bridgette_bond += 0

    f_thoughts "Most people don’t comment on that."

    f "You're observant."

    b "Sometimes."

    f "That's not a bad thing."

    f_thoughts "Neither is honesty."

    menu:
        "Does Felix say something personal?"

        "Yes — Offer a small compliment":
            f "You're easier to work with than I expected."
            $ felix_bridgette_bond += 2

        "No — Stay professional":
            f "This section's almost done."
            $ felix_bridgette_bond += 0

    b "Thanks... You're not as scary as people think, either."

    f "Scary?"

    b "Broody energy."

    f_thoughts "Broody energy. I've been called worse."

    f_thoughts "And yet... here she is. Smiling at me."

    jump f_day4_night
label f_day4_night:
    scene bg_forum with fade

    f_thoughts "Night falls."

    f_thoughts "And here... masks feel almost more honest than faces."

    window hide
    show text "Phantom: 'Even the sharpest masks crack when hearts get involved...'" with dissolve
    pause 2.0
    hide text with dissolve
    window show

    f_thoughts "Phantom."

    f_thoughts "Watching. Always watching."

    $ preferences.text_cps = 20

    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    cb "Princess Justice. My night feels emptier without your dramatics."

    pj "Coming from the king of chaos? That's rich."

    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    cb "You flatter me."

    pj "Had a weird moment today."

    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    cb "Tell me."

    pj "Caught my project partner doodling a cat."

    $ preferences.text_cps = 0

    f_thoughts "..."

    f_thoughts "Interesting."

    $ preferences.text_cps = 20

    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    cb "Clearly someone of refined taste."

    pj "Ha. Or someone hiding a lot beneath the surface."

    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    cb "Aren't we all?"

    menu:
        "How should Chat Blanc respond tonight?"

        "Encourage vulnerability":
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            cb "You notice details most people ignore. That's rare."
            $ cb_pj_bond += 2

        "Keep it light":
            play sound "audio/soft_typing_sound.mp3" loop
            $ renpy.pause(1.0)
            stop sound
            cb "Careful, Princess. Observation leads to attachment."
            $ cb_pj_bond += 1

    pj "Maybe I'm just paying attention to the right things."

    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    cb "Maybe you're seeing more than you realize."

    $ preferences.text_cps = 0

    f_thoughts "And maybe... so am I."

    jump f_day5_day
