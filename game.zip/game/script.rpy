﻿# The script of the game goes in this file.

# The game starts here.

label start:

    play music "audio/MainThemePV.mp3" volume 0.2 #By default, loop = true

    $ preferences.text_cps = 0

    # Character selection screen
    menu:
        "Choose your character:"
        "Bridgette":
            jump bridgette_route_start
        "Felix":
            jump felix_route_start

    # Sprites must be in png or webp format
    # Backgrounds can accept jpg

    #b "Hajimemashite."
    #b "Hi Chat Blanc, are you here?"
    #show f at bridgette_center
    #f "Princess Justice, you're here. What’s on your mind?"

    #b "I... just wanted to talk. I’m not sure what to say though..."
    #f "That’s okay. I like hearing from you, no matter what you say."

    return
