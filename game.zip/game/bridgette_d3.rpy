#File for Day 3 and Night 3 of Bridgette/Princess Justice
label b_day3_day:
    scene classroom with fade
    b_thoughts "Day 3. Halfway there."

    b_thoughts "I'm getting used to this... sort of."

    show felix_sketch_scaled at bridgette_center, felix_idle

    f "Morning."

    b_thoughts "Still so casual. Does anything rattle him?"

    menu:
        "How should Bridgette respond today?"

        "Friendly & More Relaxed":
            b "Morning, Felix. Sleep okay?"
            f "More or less."
            $ bridgette_felix_bond += 1

        "Awkward (Habit Can't Be Broken)":
            b "M-Morning..."
            f "..."
        
        "Tease (New Confidence?)":
            b "You know, you say that the same way every day."
            f "Consistency is key."
            $ bridgette_felix_bond += 2

    f "Are you ready to review our notes?"

    b "Ready as I'll ever be."

    # Work Session - but Bridgette is overthinking
    b_thoughts "It's kind of peaceful... working like this."

    b_thoughts "Except my brain won't shut up."

    menu:
        "Does Bridgette make conversation?"

        "Yes — Comment on something random":
            b "You have really neat handwriting, you know."
            f "Habit from fencing scorekeeping."
            b_thoughts "Of course he fences."
            $ bridgette_felix_bond += 1

        "No — Focus on Work":
            b "Let's finish this part first."
            f "Alright."
            $ bridgette_felix_bond += 0

    b "Thanks for explaining that part earlier, by the way."

    f "You're welcome. You're easier to work with than most people assume."

    play sound "audio/running_downstairs.mp3" volume 0.2
    show felix_sketch_scaled at walk_off_left
    $ renpy.pause(1.0)
    hide felix_sketch_scaled
    stop sound

    b_thoughts "Wait. What does THAT mean??"

    b "..."

    b_thoughts "Don't overthink it, Bridgette. Don't overthink it..."

    jump b_day3_night

label b_day3_night:

    scene bg_forum with fade

    b_thoughts "Back here. Back to breathing."

    window hide
    show text "Phantom: 'Funny how voices slip when they feel safe.'" with dissolve
    pause 2.0
    hide text with dissolve
    window show

    $ preferences.text_cps = 0

    b_thoughts "Phantom again..."

    $ preferences.text_cps = 20

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "Chat Blanc! You still haunting this place?"

    show screen mask_icon("cb")
    cb "Always. Where else would a ghost cat like me roam?"

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "You're ridiculous."

    show screen mask_icon("cb")
    cb "Ridiculous but reliable."

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "Rough day. Partner stuff."

    show screen mask_icon("cb")
    cb "Let me guess — unreadable, smarter than he lets on, says odd things that stick with you?"

    $ preferences.text_cps = 0

    b_thoughts ".....okay that's a little on the nose."

    narrator "How does Bridgette respond?"

    $ preferences.text_cps = 20

    menu:

        "Laugh it off":
            pj "Geez, it's like you've met him."
            $ pj_cb_bond += 1

        "Deflect":
            pj "Must be a universal guy trait."
            $ pj_cb_bond += 0

    show screen mask_icon("cb")
    cb "You'd be surprised how similar people are... behind masks or without."

    show screen mask_icon("pj")
    show screen blinking_cursor onlayer overlay
    play sound "audio/soft_typing_sound.mp3" loop
    $ renpy.pause(1.0)
    stop sound
    hide screen blinking_cursor
    pj "Maybe. But I still like this mask better."

    show screen mask_icon("cb")
    cb "And sometimes, masks protect more than they hide."

    hide screen mask_icon

    $ preferences.text_cps = 0

    b_thoughts "Why does he always sound like he's quoting poetry?"

    jump b_day4_day

